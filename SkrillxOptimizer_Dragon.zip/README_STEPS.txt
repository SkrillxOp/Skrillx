GitHub repo mein sirf 2 files replace karein: SkrillxOptimizer.py aur icon.ico
(Add file > Upload files, same naam se upload karne par purani replace ho jati hain.)
Phir Actions tab mein naya build khud chalega. Artifact se exe download karein.
